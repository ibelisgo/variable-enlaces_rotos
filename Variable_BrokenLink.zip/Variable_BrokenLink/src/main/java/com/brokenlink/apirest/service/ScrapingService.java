
package com.brokenlink.apirest.service;

import com.brokenlink.apirest.model.WebSite;
import java.io.IOException;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ibelis
 */
@Service
public interface ScrapingService{
         
    public List<WebSite> listAllLinks(String url) throws IOException;
    
    public int State_Test(String url) throws IOException;
    
    public String Evaluation(WebSite website);
   
    
}
