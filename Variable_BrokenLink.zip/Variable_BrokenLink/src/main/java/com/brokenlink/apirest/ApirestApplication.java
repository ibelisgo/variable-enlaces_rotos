package com.brokenlink.apirest;

import com.brokenlink.apirest.service.ScrapingServiceImpl;
import java.io.IOException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApirestApplication {
	public static void main(String[] args) throws IOException {
		SpringApplication.run(ApirestApplication.class, args);
                String url= "";
                ScrapingServiceImpl service= new ScrapingServiceImpl();
                service.listAllLinks(url);
                System.out.println("Total URLs:"+service.getUrlList().size());
                
                
                                        
                }
	 }


