
package com.brokenlink.apirest.controller;

import com.brokenlink.apirest.model.WebSite;
import com.brokenlink.apirest.service.ScrapingServiceImpl;
import java.io.IOException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Ibelis
 */
@RestController
@RequestMapping("scraping")
@Validated
public class ScrapingController {
    @Autowired
    private ScrapingServiceImpl scrapingservice;
    
      @GetMapping("/url")
    public List<WebSite> listAllLink(@PathVariable String url) throws IOException{
        return scrapingservice.listAllLinks(url);
    }
    
    @GetMapping
    public int State_Test(@PathVariable String url) throws IOException{
        return scrapingservice.State_Test(url);
    }
    
    @GetMapping("/")
    public String Evaluation(@RequestBody WebSite website){
        return scrapingservice.Evaluation(website);
    }
}
