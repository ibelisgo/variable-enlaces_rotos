package com.brokenlink.apirest.repository;

import com.brokenlink.apirest.model.BrokenLink;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Ibelis
 */
@Repository
public interface BrokenLinkRepository extends CrudRepository<BrokenLink, Long>{
    
    @Transactional
    Optional<BrokenLink>findByName(String name);
    
    Optional<BrokenLink>findByDescription(String description);
    
    List<BrokenLink>AllCustom();
}
