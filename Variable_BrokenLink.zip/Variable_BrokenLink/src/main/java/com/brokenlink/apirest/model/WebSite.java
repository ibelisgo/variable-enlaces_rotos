package com.brokenlink.apirest.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author Ibelis
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity(name="WebSite")
@Table(name="t_webSite")
public class WebSite implements Serializable {
   private static final long serialVersionUID = 1L;
    @Id
    @Column(name="id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long id;
    @Column(name="host")
    private String host;
    @Column(name="homepage")
    private String homepage;
    @Column(name="created_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created_time;
    @Column(name="total_url")
    private BigInteger total_url;
    @Column(name="conection_failures")
    private BigInteger conection_failures;
    @Column(name="fetched_url")
    private BigInteger fetched_url;
    @Column(name="gone_url")
    private BigInteger gone_url;
    @Column(name="not_modified_url")
    private BigInteger not_modified_url;
    @Column(name="redir_perm_url")
    private BigInteger redir_perm_url;
    @Column(name="unfetched_url")
    private BigInteger unfetched_url;
    @Column(name="id_in_directory")
    private BigInteger id_in_directory;
    @Column(name="host_telus")
    private String host_telus;
    @Column(name="relationated_link")
    private String relationed_link;
    @Column(name="total_brokenlink")
    private int total_brokenlink; 
}
