package com.brokenlink.apirest.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.type.descriptor.sql.TinyIntTypeDescriptor;

/**
 *
 * @author Ibelis
 */ @Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity(name="BrokenLink")
@Table(name="t_brokenLink")
public class BrokenLink implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name="id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long id;
    @Column(name="slug")
    private String slug;
    @Column(name="name")
    private String name;
    @Column(name="description")
    private String description;
    @Column(name="created")
    @Temporal(TemporalType.TIMESTAMP)
    private Date created;
    @Column(name="group_id")
    private BigInteger group_id;
    @Column(name="impact_id")
    private BigInteger impact_id;
    @Column(name="complexity_id")
    private BigInteger complexity_id;
    @Column(name="position")
    private int position;
    @Column(name="informative")
    private TinyIntTypeDescriptor informative;
    @Column(name="data")
    private TinyIntTypeDescriptor data;
}


