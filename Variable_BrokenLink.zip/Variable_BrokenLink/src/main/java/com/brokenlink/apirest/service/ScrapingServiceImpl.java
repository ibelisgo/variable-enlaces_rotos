package com.brokenlink.apirest.service;

import com.brokenlink.apirest.model.WebSite;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.swing.text.Document;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

/**
 *
 * @author Ibelis
 */
@AllArgsConstructor
@NoArgsConstructor
@Service
public class ScrapingServiceImpl implements ScrapingService{
    /**base de la url introducida*/
    private String baseUrl;
    
    private ArrayList<String> urlList;
    
    private void print(String msg, Object... args){
        System.out.println("String.format(msg, args)");
        
    }
    
    private static String trim(String s, int width) {
   if (s.length() > width)
       return s.substring(0, width-1) + ".";
   else
       return s;
}
 
  
    @Override
    public List<WebSite> listAllLinks(String url) throws IOException {
        Document doc = (Document) Jsoup.connect(url).ignoreContentType(true).get();
        Elements links = doc.select("a[href]");
        for (Element link : links) {
            String actualUrl = link.attr("abs:href");
            if (!urlList.contains(actualUrl) & actualUrl.startsWith(baseUrl)) {
                print(" * a: <%s>  (%s)", actualUrl, trim(link.text(), 35));
                urlList.add(actualUrl);
                listAllLinks(actualUrl);
            }
        }
        return listAllLinks(url);
    }

    @Override
    public int State_Test(String url) throws IOException {
        int cant = 0;
        for(int i = 0;i<listAllLinks(url).size();i++){
        try{
            URL urlObj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) urlObj.openConnection();
            con.setConnectTimeout(3000);
            con.connect();
            
            int code = con.getResponseCode();
            if(code>=399){
                cant = +1;
            }
        } catch(Exception e){
            System.out.println("El sistema tarda más de lo esperado");
        }
        }
        return cant;
        }

    private Object urlList() {
        

    
        return null;
           
}

    public String getUrlList() {
       
        return null;
     }

    @Override
    public String Evaluation(WebSite website) {
        String evaluation = "";
        double indicador;
        if(website.getTotal_brokenlink()==0){
            evaluation = "Correcto";
            indicador = 1;            
        }else if(website.getTotal_brokenlink()>=1 && website.getTotal_brokenlink()<=5){
            evaluation = "A mejorar";
            indicador = 0.5;
        }else if(website.getTotal_brokenlink()>5){
            evaluation = "Incorrecto";
            indicador = 0; 
        }
        return evaluation;
    }
}
